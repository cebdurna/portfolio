An ableton liveset is included to provide an output for midi signals received from the microcontroller.

In order to achieve the demo functionality.

1) Upload MusicBox.ino code to the microcontroller.

2) Open the included Ableton Live set.

3) Connect the microcontroller via USB.

3) Enjoy...