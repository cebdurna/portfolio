import pandas as pd
import numpy as np

# Load your CSV file
file_path = 'output.csv'  # Replace with your file path
df = pd.read_csv(file_path)

# Convert the timestamp columns to datetime format
# Replace 'start_time' and 'end_time' with the actual column names in your file
df['start_time'] = pd.to_datetime(df['start_time'], unit='s')
df['end_time'] = pd.to_datetime(df['end_time'], unit='s')
df['created_at'] = pd.to_datetime(df['end_time'], unit='s')

date_to_keep = '2024-10-30'
columns_to_keep = ['app', 'usage', 'seconds_since_day_start']
filtered_df = df[(df['created_at'].dt.date == pd.to_datetime(date_to_keep).date())
                 | (df['created_at'].dt.date == pd.to_datetime("2024-10-31").date())]
filtered_df['created_at'] = df['created_at']  - pd.Timedelta(hours=7)
filtered_df['date_only'] = df['created_at'].dt.date 
filtered_df['seconds_since_day_start'] = df['created_at'].dt.hour * 3600 + \
                                df['created_at'].dt.minute * 60 + \
                                df['created_at'].dt.second
filtered_df = filtered_df[columns_to_keep]
secondsTimeFrame = 900
filtered_df['15_interval'] = np.floor(filtered_df['seconds_since_day_start'] / secondsTimeFrame).astype(int)
sorted_df = filtered_df.sort_values(by='seconds_since_day_start', ascending=True)

summed_df = sorted_df.groupby('15_interval', as_index=False).sum()

# Save the result to a new CSV
summed_df.to_csv('summed_rows.csv', index=False)

# Save the modified DataFrame to a new CSV
sorted_df.to_csv('converted_with_time_difference.csv', index=False)

currentMin = 0
results = []
tempResults = []


